#include <stdio.h>

int main() {

    int count = 10;

    while (count > 0) {
        printf("%d\n", count);
        count --;
    }

    return 0;
}